---
title: Reliable Component Grouping Pattern
category: Canvas Management
---

### Pattern: Programmatic Component Grouping
This pattern describes how to reliably group existing Grasshopper components into a named container using Shiba Assembly or backend scripts.

#### Workflow:
1. **Identify GUIDs**: Use `investigate_canvas` or `get_selected_components` to retrieve the unique instance GUIDs of the target components.
2. **Define Group**: Create a `Group` component (`N ... | Group | Special`).
3. **Configure Members**: Use the `C` command with the `ids` parameter, passing a semicolon-separated list of GUIDs.
4. **Backend Verification (Optional)**: If the shorthand fails to bind members (common in complex canvas states), use a backend script to force the association.

#### Shiba Assembly Example:
```shiba
# PROMPT: Group specific components into a 'Grid Setup' group.
N grp_grid | Group | Special
C grp_grid | n=Grid Setup, c=#ABDBFF, ids=GUID_1;GUID_2;GUID_3
```

#### C# Backend Fallback:
```csharp
using Grasshopper.Kernel.Special;
var doc = Grasshopper.Instances.ActiveCanvas.Document;
GH_Group group = new GH_Group();
group.NickName = "Group Name";
group.AddObject(new Guid("..."));
doc.AddObject(group, false);
```

#### Lessons Learned:
- Always check if the group is empty after creation using `test_in_sandbox`.
- If `execute_shorthand` creates an empty group, it is usually due to GUID mismatch or the group being added before the objects are fully registered in the document's lookup table.
- Use `tidy_up_canvas` after grouping to ensure the group boundary encapsulates the components visually.
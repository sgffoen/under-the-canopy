---
title: Vaulted Truss Data Tree Lessons
category: Troubleshooting & Lessons
---

# Lessons from Vaulted Truss Data Tree Management

### 1. Path Complexity in Relative Item
**Problem:** When using `Divide Curve` on a list of curves with Graft (m=g) applied to the input, the output points often have deeply nested paths (e.g., `{0;0;0}`, `{0;0;1}`). The `Relative Item` component's offset parameter (e.g., `{1}(1)`) is highly sensitive to the number of integers in the path. If the path has 3 integers but the offset only targets 1, the component fails to find the relative branch.

**Solution:** 
- Use `Trim Tree` with a specific depth to strip redundant leading zeroes.
- Use `Simplify` (s=true) on the output port of the division component.
- Ensure the `Offset` string in `Relative Item` matches the tree topology (e.g., if paths are `{0}`, use `{1}`; if paths are `{0;0}`, use `{0;1}`).

### 2. X-Bracing Logic via List/Tree Shifts
To create diagonal bracing between two divided curves (Branch A and Branch B):
- **Diagonal 1 (A[i] to B[i+1])**: Requires a shift in the list of points (i+1) AND a shift in the branches (A to B).
- **Diagonal 2 (A[i+1] to B[i])**: Requires a shift in the list of points (i+1) on the starting side.
- **Implementation**: In Shiba Assembly, this is most reliably done by:
    1. Dividing curves to get a tree of points `T`.
    2. Creating `T_shifted_list` using `Shift List` (S=1).
    3. Creating `T_shifted_branch` using `Relative Item` or `Shift Paths`.
    4. Connecting `Line(T, T_shifted_both)` and `Line(T_shifted_list, T_shifted_branch)`.
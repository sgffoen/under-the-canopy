---
title: Create Line Script
category: Geometry Creation
---

import Rhino.Geometry as rg
import Rhino

def create_line(start_pt, end_pt):
    line = rg.Line(start_pt, end_pt)
    id = Rhino.RhinoDoc.ActiveDoc.Objects.AddLine(line)
    return id

# Example usage:
# start = rg.Point3d(0, 0, 0)
# end = rg.Point3d(10, 10, 0)
# create_line(start, end)

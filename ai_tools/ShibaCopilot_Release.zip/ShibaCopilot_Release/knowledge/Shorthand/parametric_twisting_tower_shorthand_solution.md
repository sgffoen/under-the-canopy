---
title: Parametric Twisting Tower Shorthand Solution
category: Shorthand
---

# PROMPT: Full Parametric Twisting Tower with Visualization
# Stage 1: Inputs
N sld_floors | Number Slider | Params
C sld_floors | val=20, min=5, max=100, d=0
N sld_height | Number Slider | Params
C sld_height | val=4.0, min=3.0, max=10.0, d=1
N sld_radius | Number Slider | Params
C sld_radius | val=15.0, min=5.0, max=50.0, d=1
N sld_sides | Number Slider | Params
C sld_sides | val=6, min=3, max=12, d=0
N sld_twist | Number Slider | Params
C sld_twist | val=90.0, min=0.0, max=360.0, d=1

# Stage 2: Base & Array
N poly | Polygon | Curve
W sld_radius.0 > poly.1
W sld_sides.0 > poly.2
N series | Series | Sets
P series.i0 | val=0
W sld_height.0 > series.1
W sld_floors.0 > series.2
N vec_z | Unit Z | Vector
W series.0 > vec_z.0
N move | Move | Transform
W poly.0 > move.0
W vec_z.0 > move.1

# Stage 3: Twist Logic
N dom | Construct Domain | Maths
P dom.i0 | val=0
W sld_twist.0 > dom.1
N range | Range | Sets
W dom.0 > range.0
W sld_floors.0 > range.1
P range.i1 | x=x-1
N rad | Radians | Maths
W range.0 > rad.0
N area | Area | Surface
W move.0 > area.0
N rot | Rotate | Transform
W move.0 > rot.0
W rad.0 > rot.1
W area.1 > rot.2

# Stage 4: Form & Viz
N loft | Loft | Surface
W rot.0 > loft.0
N slabs | Boundary Surfaces | Surface
W rot.0 > slabs.0
N col_skin | Colour Swatch | Params
C col_skin | val=#ABDBFF, a=100
N col_slabs | Colour Swatch | Params
C col_slabs | val=#FFFFFF, a=255
N prev_skin | Custom Preview | Display
W loft.0 > prev_skin.0
W col_skin.0 > prev_skin.1
N prev_slabs | Custom Preview | Display
W slabs.0 > prev_slabs.0
W col_slabs.0 > prev_slabs.1

# Hygiene
S poly | h=true
S move | h=true
S rot | h=true
S loft | h=true
S slabs | h=true
---
title: Consolidated Twisted Tower Shorthand Snippet
category: Shorthand Snippet
---

# PROMPT: Consolidated Twisted Tower Shorthand
# Note: This snippet assumes a fresh start or can be adapted with GUIDs.

# 1. Inputs
N sld_rad | Number Slider | Params | C sld_rad | val=15.0, min=5.0, max=50.0, d=1
N sld_floors | Number Slider | Params | C sld_floors | val=20, min=5, max=100, d=0
N sld_h | Number Slider | Params | C sld_h | val=3.5, min=2.0, max=10.0, d=1
N sld_seg | Number Slider | Params | C sld_seg | val=4, min=3, max=12, d=0
N sld_twist | Number Slider | Params | C sld_twist | val=90.0, min=0.0, max=360.0, d=1

# 2. Base Stack
N poly | Polygon | Curve
W sld_rad.0 > poly.1
W sld_seg.0 > poly.2

N ser | Series | Sets
P ser.i0 | val=0
W sld_h.0 > ser.1
W sld_floors.0 > ser.2

N uz | Unit Z | Vector
W ser.0 > uz.0

N mov | Move | Transform
W poly.0 > mov.0
W uz.0 > mov.1

# 3. Twist Logic
N area | Area | Surface
W mov.0 > area.0

N dom | Construct Domain | Math
P dom.i0 | val=0
W sld_twist.0 > dom.1

N sub | Subtraction | Math
W sld_floors.0 > sub.0
P sub.i1 | val=1

N rng | Range | Sets
W dom.0 > rng.0
W sub.0 > rng.1

N rad | Radians | Math
W rng.0 > rad.0

N rot | Rotate | Transform
W mov.0 > rot.0
W rad.0 > rot.1
W area.1 > rot.2

# 4. Outputs
N loft | Loft | Surface
W rot.0 > loft.0

N bnd | Boundary Surfaces | Surface
W rot.0 > bnd.0

N col_skin | Colour Swatch | Params | C col_skin | val=#ABDBFF, a=100
N col_slabs | Colour Swatch | Params | C col_slabs | val=#808080, a=255

N prev_skin | Custom Preview | Display
W loft.0 > prev_skin.0
W col_skin.0 > prev_skin.1

N prev_slabs | Custom Preview | Display
W bnd.0 > prev_slabs.0
W col_slabs.0 > prev_slabs.1

# 5. Hygiene
S poly | h=true
S mov | h=true
S rot | h=true
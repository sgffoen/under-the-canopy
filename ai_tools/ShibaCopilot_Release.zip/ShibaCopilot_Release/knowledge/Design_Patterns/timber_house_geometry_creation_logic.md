---
title: Timber_House_Geometry_Creation_Logic
category: Design_Patterns
---

### Parametric Timber House Logic (Standardized)

#### 1. Foundation (Footprint)
- **Component**: `Rectangle` -> `Explode`.
- **Logic**: Use `List Item` to categorize segments into 'Joist Supports' (Indices 0, 2) and 'Eave Supports' (Indices 1, 3).

#### 2. Floor Joists (Horizontal)
- **Logic**: Select parallel base segments. Align directions using `Flip Curve`. Divide by spacing. Connect with `Line`.
- **Key Component**: `Flip Curve` is mandatory to prevent diagonal joists.

#### 3. Wall Studs (Vertical)
- **Logic**: Divide the entire exploded segment list by spacing. Use `Line SDL` with `Unit Z` direction.
- **Key Component**: `Line SDL` allows for easy height control via a single slider.

#### 4. Gabled Roof (Inclined)
- **Ridge**: Find midpoints of gable-end segments. Create a line. Move it by `Wall Height + Pitch Height`.
- **Eaves**: Move eave segments to `Wall Height`.
- **Rafters**: Align eaves to Ridge direction. Divide all three (Ridge, Eave1, Eave2) by the same spacing. Connect Ridge points to Eave points.

#### 5. Visualization
- **Logic**: Group by system (Floor, Wall, Roof). Use `Custom Preview` with distinct wood-tone hex codes.
- **Colors**: Floor (#8B4513), Walls (#DEB887), Roof (#A0522D).
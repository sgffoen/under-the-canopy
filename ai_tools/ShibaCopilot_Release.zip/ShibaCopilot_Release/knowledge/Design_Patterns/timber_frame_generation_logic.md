---
title: Timber_Frame_Generation_Logic
category: Design_Patterns
---

### Parametric Timber Frame Logic

#### 1. Wall Studs (Vertical Members)
- **Base**: `Rectangle` -> `Explode` (Segments).
- **Distribution**: `Divide Length` on segments using a spacing slider (e.g., 0.6m).
- **Generation**: `Line SDL` using the division points as `Start`, `Unit Z` as `Direction`, and a height slider as `Length`.

#### 2. Floor Joists (Horizontal Spanning)
- **Selection**: `List Item` to pick two parallel segments from the floor plate (e.g., Index 0 and 2).
- **Alignment**: `Flip Curve` on the second segment using the first as a `Guide`.
- **Generation**: `Divide Length` on both curves; connect corresponding points with a `Line` component.

#### 3. Gable Roof Rafters (Inclined Members)
- **Ridge Creation**: Find midpoints of gable-end segments (`Point on Curve` at 0.5). Create a `Line` between midpoints and `Move` it vertically.
- **Alignment**: `Flip Curve` on eave segments using the Ridge as a `Guide`.
- **Generation**: `Divide Length` on the Ridge and both Eaves. Create `Line` members from Ridge points to Eave points.

#### 4. Visualization
- Use `Merge` to collect similar structural types.
- Apply `Custom Preview` with `Colour Swatch` for material-based coding (e.g., Wood=Brown, Steel=Blue).
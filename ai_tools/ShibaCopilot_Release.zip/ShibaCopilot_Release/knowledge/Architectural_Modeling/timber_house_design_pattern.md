---
title: Timber_House_Design_Pattern
category: Architectural_Modeling
---

# Timber House Structural Logic (2-Storey)

This pattern generates a structurally aligned timber frame house including wall studs, floor joists, and a gable roof.

## 1. Wall Studs (Vertical Members)
- **Logic**: Explode the base footprint (Rectangle) into segments. Use `Divide Length` with a spacing slider (e.g., 0.6m).
- **Generation**: Use `Line SDL` with `Unit Z` as the direction and `Floor Height` as the length.
- **Stacking**: `Move` the base footprint by `Unit Z * Floor Height` to generate the second floor and repeat the stud logic.

## 2. Floor Joists (Horizontal Members)
- **Logic**: Select parallel segments from the floor plate (e.g., Index 0 and 2).
- **Alignment (Critical)**: Use `Flip Curve` on the second segment using the first as a `Guide`. This ensures `Divide Length` points are indexed in the same direction.
- **Generation**: `Line` between the points of the two divided curves.

## 3. Gable Roof Rafters (Pitched Members)
- **Ridge Line**: Find the midpoints of the gable-end segments (e.g., Index 1 and 3) using `Point on Curve` at 0.5. Create a `Line` and `Move` it vertically by `Floor Height + Roof Height`.
- **Eave Lines**: Select the side segments of the top floor plate.
- **Alignment**: `Flip Curve` the eave segments using the `Ridge Line` as a `Guide`.
- **Generation**: `Line` from the divided Ridge points to the divided Eave points.

## 4. Data Management
- Use `Merge` (with ZUI expansion) to collect all structural lines for a single `Custom Preview`.
- Use `Colour Swatch` (#8B4513) for timber visualization.
---
title: Timber_House_Structural_Logic
category: Architectural_Modeling
---

# Timber House Structural Modeling Logic

This pattern generates a 2-storey timber frame house including floor joists, wall studs, and a gable roof.

## 1. Base Footprint & Inputs
- **Inputs**: Width (X), Depth (Y), Floor Height (H), Structural Spacing (S), Roof Height (RH).
- **Base**: `Rectangle` -> `Explode` (Segments).

## 2. Floor Joists (Alignment Fix)
- **Selection**: Use `List Item` to pick parallel segments (Index 0 and 2).
- **Alignment**: Use `Flip Curve` on the second segment with the first as a `Guide`. This ensures `Divide Length` points align perfectly across the span.
- **Generation**: `Line` between corresponding division points.

## 3. Wall Studs
- **Distribution**: `Divide Length` on all footprint segments using the Spacing slider.
- **Generation**: `Line SDL` with `Unit Z` direction and Floor Height as length.

## 4. Multi-Storey Stacking
- **Logic**: `Move` the base footprint by `Unit Z * Floor Height` to create the next floor plate.
- **Top Plate**: For the roof, move the highest floor plate again by the floor height to create the "Top Plate" (Eave level).

## 5. Gable Roof Rafters
- **Ridge**: Find midpoints of gable-end segments (`Point on Curve` at 0.5). Create a `Line` and `Move` it vertically by Roof Height.
- **Eaves**: Use the Top Plate segments.
- **Alignment**: `Flip Curve` eave segments using the Ridge as a `Guide`.
- **Generation**: `Line` from Ridge division points to Eave division points.

## 6. Visualization
- `Merge` all structural lines.
- `Custom Preview` with a `Colour Swatch` (e.g., Timber Brown #8B4513).
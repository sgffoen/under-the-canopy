---
title: Timber_2-Storey_House_Structure
category: Architectural_Modeling
---

# Parametric Timber 2-Storey House Structure

This workflow generates a clean, aligned timber frame for a two-storey house, including wall studs, floor joists, and gable roof rafters. It specifically addresses the common issue of "twisted" geometry caused by inconsistent curve directions.

## Key Components & Logic:
1. **Wall Studs:**
   - Base `Rectangle` exploded into segments.
   - `Divide Curve` on segments to generate point arrays.
   - `Line SDL` (Unit Z) to create vertical studs.
   - `Move` (Unit Z * Floor Height) to stack the second storey.

2. **Floor Joists (Alignment Fix):**
   - Isolate parallel footprint segments using `List Item`.
   - **CRITICAL:** Use `Flip Curve` on the second segment with the first as a `Guide` to ensure matching directions.
   - `Divide Curve` and `Line` (Point A to Point B) to span the joists.

3. **Gable Roof Rafters (Alignment Fix):**
   - Create a ridge line by moving the midpoint of the top plate.
   - **CRITICAL:** Use `Flip Curve` on the top plate eave segments using the `Ridge Line` as a `Guide`.
   - `Divide Curve` on the ridge and aligned eaves.
   - `Line` to bridge ridge points to eave points.

4. **Visualization:**
   - `Custom Preview` with `Colour Swatch` (Red: Studs, Blue: Joists, Green: Rafters).

## Prevention of Twisted Geometry:
Always align curve directions before dividing and connecting points. Inconsistent directions result in crossed wires. The `Flip Curve` component with a `Guide` input is the standard solution for maintaining parametric alignment across parallel members.
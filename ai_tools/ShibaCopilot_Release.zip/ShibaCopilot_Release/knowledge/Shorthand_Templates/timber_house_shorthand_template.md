---
title: Timber_House_Shorthand_Template
category: Shorthand_Templates
---

# PROMPT: Full 2-Storey Timber House Structure
# Stage 1: Inputs
N sld_w | Number Slider | Params | C sld_w | val=10.0, min=5.0, max=20.0, d=1
N sld_d | Number Slider | Params | C sld_d | val=8.0, min=5.0, max=20.0, d=1
N sld_h | Number Slider | Params | C sld_h | val=3.0, min=2.4, max=4.0, d=1
N sld_s | Number Slider | Params | C sld_s | val=0.6, min=0.4, max=1.2, d=2
N sld_rh | Number Slider | Params | C sld_rh | val=2.5, min=1.0, max=5.0, d=1

# Stage 2: Footprints
N rect | Rectangle | Curve | W sld_w.0 > rect.1 | W sld_d.0 > rect.2
N move_l2 | Move | Transform | W rect.0 > move_l2.0 | N vec_z | Unit Z | Vector | W sld_h.0 > vec_z.0 | W vec_z.0 > move_l2.1
N move_tp | Move | Transform | W move_l2.0 > move_tp.0 | W vec_z.0 > move_tp.1

# Stage 3: Studs
N expl1 | Explode | Curve | W rect.0 > expl1.0
N div1 | Divide Length | Curve | W expl1.0 > div1.0 | W sld_s.0 > div1.1
N studs1 | Line SDL | Curve | W div1.0 > studs1.0 | W vec_z.0 > studs1.1 | W sld_h.0 > studs1.2

N expl2 | Explode | Curve | W move_l2.0 > expl2.0
N div2 | Divide Length | Curve | W expl2.0 > div2.0 | W sld_s.0 > div2.1
N studs2 | Line SDL | Curve | W div2.0 > studs2.0 | W vec_z.0 > studs2.1 | W sld_h.0 > studs2.2

# Stage 4: Roof
N expl_tp | Explode | Curve | W move_tp.0 > expl_tp.0
N mid1 | Point on Curve | Curve | W expl_tp.0 > mid1.0 | P mid1.i1 | val=0.5 | P mid1.i0 | val=1
N mid2 | Point on Curve | Curve | W expl_tp.0 > mid2.0 | P mid2.i1 | val=0.5 | P mid2.i0 | val=3
N ridge_b | Line | Curve | W mid1.0 > ridge_b.0 | W mid2.0 > ridge_b.1
N ridge | Move | Transform | W ridge_b.0 > ridge.0 | N vec_rh | Unit Z | Vector | W sld_rh.0 > vec_rh.0 | W vec_rh.0 > ridge.1
N div_r | Divide Length | Curve | W ridge.0 > div_r.0 | W sld_s.0 > div_r.1

N li_e1 | List Item | List | W expl_tp.0 > li_e1.0 | P li_e1.i1 | val=0
N flip_e1 | Flip Curve | Curve | W li_e1.0 > flip_e1.0 | W ridge.0 > flip_e1.1
N div_e1 | Divide Length | Curve | W flip_e1.0 > div_e1.0 | W sld_s.0 > div_e1.1
N raft1 | Line | Curve | W div_r.0 > raft1.0 | W div_e1.0 > raft1.1

# Visualization
N merge | Merge | Tree | Z merge | i=3, o=1 | W studs1.0 > merge.0 | W studs2.0 > merge.1 | W raft1.0 > merge.2
N preview | Custom Preview | Display | W merge.0 > preview.0 | N col | Colour Swatch | Params | C col | val=#8B4513 | W col.0 > preview.1
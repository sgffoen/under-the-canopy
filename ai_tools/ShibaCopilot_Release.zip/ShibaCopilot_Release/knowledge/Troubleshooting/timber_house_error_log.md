---
title: Timber_House_Error_Log
category: Troubleshooting
---

### Error: Rectangle Component Type Mismatch
**Symptom**: `Data conversion failed from Number to Plane` on the `Rectangle` component.
**Cause**: Wiring a Number Slider directly into the first input (P) of the `Rectangle` component. The first input expects a `Plane`, while the dimensions (X and Y) are the second and third inputs.
**Fix**: Ensure `X Size` is wired to port index 1 and `Y Size` is wired to port index 2. Port index 0 should be left at default (World XY) or provided with a Plane.

### Error: Merge Component Port Not Found
**Symptom**: `Port not found` when wiring to a `Merge` component via shorthand.
**Cause**: The `Merge` component is a ZUI (Zoomable User Interface) component. By default, it may only have two input ports.
**Fix**: Use the `Z` command in Shiba Assembly to explicitly set the input count (e.g., `Z merge_all | i=6, o=1`) before attempting to wire to indices higher than 1.

### Error: Twisted/Crossed Geometry in Joists/Rafters
**Symptom**: Lines connecting two divided curves appear crossed or diagonal instead of parallel.
**Cause**: The two boundary curves have inconsistent directions (one runs clockwise, the other counter-clockwise).
**Fix**: Use the `Flip Curve` component. Input the curve to be flipped into `C` and the reference/guide curve into `G`. This ensures both curves share the same topological direction before division.
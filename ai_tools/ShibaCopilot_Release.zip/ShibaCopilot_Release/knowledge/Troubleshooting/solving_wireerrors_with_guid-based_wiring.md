---
title: Solving WireErrors with GUID-based Wiring
category: Troubleshooting
---

### Issue: WireError - Port Not Found
**Context:** Occurred when attempting to wire existing components using their Nicknames (e.g., `W ln_col_l.0 > mov_col_l.0`) in a subsequent shorthand block.
**Root Cause:** The Shiba Engine requires the exact `Unique ID` (GUID) of existing components for wiring if they were created in a previous turn, as nicknames are not globally unique or persistent for direct wiring in the assembly logic.
**Solution:** 
1. Run `investigate_canvas` to retrieve the exact GUIDs of the target components.
2. Use the GUIDs in the `W` command (e.g., `W e3c0bd8c-0bd5-452b-ba46-e1968e54e13d.0 > mov_col_l.0`).
3. Ensure the port index (e.g., `.0`) matches the Master Dictionary for that component type.
---
title: Debugging Rotate Component Type Mismatch in Grasshopper
category: Troubleshooting
---

### Issue: Rotate Component Type Mismatch
During the construction of the parametric skyscraper, a runtime error occurred: `Data conversion failed from Number to Vector`.

### Root Cause:
The `Rotate` component in the `Vector` category (GUID: `a932520e-8442-4053-a43e-ccf1ccbbc0b6`) was accidentally used. This component is designed to rotate vectors and expects a Vector for the Axis at input port 1. However, the logic required rotating geometry (Rectangle curves) using an Angle in radians.

### Solution:
Switch to the `Rotate` component in the `Transform > Euclidean` category (GUID: `b7798b74-037e-4f0c-8ac7-dc1043d093e0`). 
- **Input 0 (G)**: Geometry to rotate.
- **Input 1 (A)**: Angle in radians (connected from a `Radians` component).
- **Input 2 (P)**: Rotation plane or center point (connected from the `Centroid` output of an `Area` component).

### Key Takeaway:
Always verify the category and expected input types of the `Rotate` component. For geometric transformations, use the `Transform` version. For vector math, use the `Vector` version.
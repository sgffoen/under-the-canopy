---
title: Common Errors in Parametric Stacking Workflows
category: Troubleshooting
---

### Issue: Scale Factor Zero Error
When using a `Graph Mapper` or `Range` to drive a `Scale` component, the default domain often starts at 0.0. Grasshopper's `Scale` component throws a "Cannot scale with factor zero" error if any input factor is 0.

### Solution:
Always use a `Remap Numbers` component or a `Construct Domain` to ensure the scale factor has a non-zero minimum (e.g., 0.5 to 1.5).

### Issue: Loft Data Tree Mismatch
When lofting a series of transformed curves (like those from a `Move` or `Rotate` component), the data is often structured in separate branches (e.g., `t={0;0}(1), t={0;1}(1)...`). `Loft` requires all curves to be in the same branch to create a single surface.

### Solution:
Apply a `Flatten` (m=f) modifier to the `Loft` input port to merge all curves into a single list.

### Issue: Port Indexing for Math Components
Standard math components like `Subtraction` or `Construct Domain` have specific port indices (0 for A/Start, 1 for B/End). Wiring to the wrong index or using `val=` on the wrong port causes build failures.

### Solution:
Verify port indices using `search_components`. For `Subtraction`, `i0` is the base and `i1` is the value to subtract.
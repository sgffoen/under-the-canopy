---
title: Solving Port Not Found Errors in Incremental Builds
category: Troubleshooting
---

### Issue: Port Not Found Errors in Shorthand
During the construction of the Parametric Bridge, several `WireError` messages occurred (e.g., `Port not found` for `sld_width`, `deck_crv`, etc.).

### Root Cause
The Shiba Assembly compiler requires precise identification of components. When using `clean_previous=False` to build incrementally, referring to components by their `Nickname` (e.g., `sld_width`) can fail if the compiler loses track of the specific instance or if multiple components share the same nickname.

### Solution
1. **Investigate Canvas:** Run `investigate_canvas` to retrieve the exact `Unique ID` (GUID) for every existing component.
2. **Explicit Wiring:** Use the GUIDs directly in the `W` (Wire) commands instead of nicknames.
   - *Example:* `W d0fc0a0a-ccd6-43ff-a550-76ae84cad8dc.0 > div_width.i0` instead of `W sld_width.0 > div_width.i0`.
3. **Category Verification:** Ensure the `Category` in the `N` command matches the Master Dictionary (e.g., `Maths` vs `Math`).

### Lesson
Always use `investigate_canvas` between incremental steps to ensure the next block of shorthand uses the correct GUIDs for upstream dependencies.
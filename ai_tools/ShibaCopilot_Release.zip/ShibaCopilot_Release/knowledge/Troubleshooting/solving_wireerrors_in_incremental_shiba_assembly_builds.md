---
title: Solving WireErrors in Incremental Shiba Assembly Builds
category: Troubleshooting
---

### Issue: WireError during Incremental Builds
When building Grasshopper definitions incrementally using Shiba Assembly, a common error is `WireError: Port not found` or `WireError: FromID not found`.

### Root Cause
This typically happens when the `W` (Wire) command attempts to connect to a component using its `Nickname` or a temporary `ID` from a previous block that was not correctly mapped to the live canvas `Unique ID` (GUID).

### Solution
1. **Investigate Canvas**: Run `investigate_canvas` after every `execute_shorthand` call to retrieve the actual GUIDs of the spawned components.
2. **Explicit GUID Wiring**: In the subsequent shorthand block, use the exact GUIDs (e.g., `c2a07424-0b44-4dc2-b16d-5f9ee119db75`) for the `FromID` in the `W` command.
3. **Port Verification**: Ensure the port indices (e.g., `.0`, `.1`) match the component's SDK definition. For example, `Move` input 0 is Geometry, input 1 is Motion.

### Example Fix
- **Failed**: `W mov.0 > area.0` (where `mov` was a nickname).
- **Fixed**: `W c2a07424-0b44-4dc2-b16d-5f9ee119db75.0 > area.0` (using the GUID from the canvas investigation).
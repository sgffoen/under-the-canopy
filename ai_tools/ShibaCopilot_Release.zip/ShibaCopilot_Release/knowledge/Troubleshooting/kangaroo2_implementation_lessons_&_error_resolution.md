---
title: Kangaroo2 Implementation Lessons & Error Resolution
category: Troubleshooting
---

### Kangaroo2 Component Identification & Wiring Errors

#### 1. Component Naming & GUIDs
- **Issue**: Standard names like 'Bouncy Solver' or 'Edge Lengths' failed during `execute_shorthand` because the compiler requires the exact internal `Name` or `GUID`.
- **Discovery**: Used `test_in_sandbox` with `GH_ComponentServer` to list all Kangaroo2 proxies.
- **Resolution**: 
    - 'Bouncy Solver' -> `BouncySolver` (No space).
    - 'Edge Lengths' -> `EdgeLengths` (No space).
    - 'Show' -> `Show`.
    - 'Anchor' -> `Anchor`.

#### 2. EdgeLengths Input Type Mismatch
- **Issue**: Attempted to wire `Mesh Edges` (Lines) into the `Mesh` input of `EdgeLengths`.
- **Error**: `Data conversion failed from Line to Mesh`.
- **Resolution**: The `EdgeLengths` component in Kangaroo2 (Goals-Mesh) expects the **Mesh object itself** as the first input. It internally extracts the edges to create the length goals. Wiring the `Mesh` directly fixed the runtime error.

#### 3. Solver Output Indexing
- **Issue**: The `BouncySolver` output `O` (GoalObjects) is a flat list containing all processed goals and geometry.
- **Discovery**: Investigated `volatileDataCount` of the solver output. With 105 anchors, 1332 edge goals, and 1 show goal, the total count was 1438.
- **Resolution**: To extract the final relaxed mesh for visualization, used `List Item` with index `1437` (the last item, which corresponded to the `Show` goal geometry).

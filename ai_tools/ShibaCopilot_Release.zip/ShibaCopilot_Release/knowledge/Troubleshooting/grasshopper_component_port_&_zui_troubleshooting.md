---
title: Grasshopper Component Port & ZUI Troubleshooting
category: Troubleshooting
---

# Grasshopper Component Port & ZUI Lessons

### 1. Merge & Entwine (Multi-Input Components)
- **Issue**: Using the `Z` command to expand a standard `Merge` component sometimes results in "Port not found" errors if the system expects specific multi-input GUIDs.
- **Solution**: Use specific components like `Merge 03` or `Merge 04` if available in the dictionary, or ensure the `Z` command is applied to a component that explicitly supports ZUI expansion in the target environment.
- **Entwine**: Always check if the ports are named by index (0, 1, 2) or by path strings. In Shiba Assembly, use integer indices.

### 2. Construct Domain
- **Issue**: `Construct Domain` expects two numeric inputs (Start and End).
- **Indices**: 
  - `0`: Domain Start (A)
  - `1`: Domain End (B)
- **Common Error**: Wiring a slider to an index that doesn't exist or is mislabeled in the shorthand.

### 3. Divide Curve
- **Indices**:
  - `0`: Curve (C)
  - `1`: Count (N)
  - `2`: Kinks (K)
- **Outputs**:
  - `0`: Points (P)
  - `1`: Tangents (T)
  - `2`: Parameters (t)

### 4. Wire Errors & GUID Persistence
- **Lesson**: When building incrementally, ensure that the GUIDs of previously spawned components are correctly referenced in subsequent `W` (Wire) commands. If a build fails, the `clean_previous=True` flag or `cleanup_canvas()` should be used to avoid overlapping components with duplicate logic.

---
title: Parametric Arched Suspension Bridge Logic
category: Architectural Design
---

# Parametric Arched Suspension Bridge Pattern

This pattern creates a bridge with a cambered deck and a central parabolic arch supporting the edges via suspension cables.

## Geometric Logic
1. **Longitudinal Profile:**
   - Define `Start Point` {0,0,0} and `End Point` {L,0,0}.
   - Create a `Midpoint` {L/2, 0, Camber} for the deck and {L/2, 0, ArchHeight} for the arch.
   - Generate two `Arc 3Pt` curves using these point sets.
2. **Transverse Deck Generation:**
   - Offset the Deck Arc in the Y and -Y directions by `Width/2`.
   - Create a `Ruled Surface` between these two edge curves.
3. **Structural Integration:**
   - Divide the Arch Arc and both Deck Edge curves by the same `Count`.
   - Connect the Arch points to the Left Edge points and Right Edge points using `Line` components.
4. **Volumetric Representation:**
   - Merge the Arch curve and all Cable lines.
   - Apply a `Pipe` component to the merged list for 3D geometry.

## Key Components
- `Arc 3Pt`: For the organic profile of the deck and arch.
- `Move` + `Unit Y` + `Negative`: To create the deck width symmetrically.
- `Divide Curve`: To generate anchor points for cables.
- `Ruled Surface`: To create the walkable deck area.
- `Pipe`: To turn wireframe curves into structural members.

## Best Practices
- Use a `Camber` value > 0 to prevent the bridge from looking "flat" or sagging visually.
- Group inputs (Length, Width, Height, Divisions) together for easy user interaction.
- Use `Custom Preview` with distinct colors for the deck (concrete/wood) and structure (steel).
---
title: Parametric Vaulted Truss Workflow
category: Architectural Design
---

# Parametric Vaulted Truss Workflow

This workflow generates a structural vault with arches, longitudinal purlins, and diagonal X-bracing.

## Geometric Logic
1. **Profile Generation**: Create a base arch using `Arc 3Pt` (Start, Mid, End). The Midpoint is elevated by a 'Height' slider.
2. **Linear Array**: Use `Series` and `Unit Y` to create a sequence of vectors. `Move` the base arch along these vectors to define the vault length.
3. **Point Grid**: `Divide Curve` all arches by a 'Divisions' count. This creates a 2D grid of points organized by Arch (Branches) and Segment (List Items).
4. **Longitudinal Members (Purlins)**:
   - Use `Flip Matrix` on the point grid to group points by their position along the arch.
   - Use `Polyline` to connect these points across the arches.
5. **Diagonal Bracing (X-Bracing)**:
   - Use `Shift List` and `Relative Item` (or branch shifting) to cross-connect points between Arch $i$ and Arch $i+1$.
   - Connect `Line` components between the original grid and the shifted grids to form the "X" pattern.
6. **Volumetric Representation**:
   - `Merge` the Arches, Purlins, and Diagonals.
   - Apply `Pipe` with a small radius to create the 3D mesh.

## Key Components
- `Arc 3Pt`, `Series`, `Move`, `Divide Curve`, `Flip Matrix`, `Shift List`, `Relative Item`, `Pipe`.
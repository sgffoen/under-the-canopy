---
title: Parametric Wavy 3D Truss Logic and Workflow
category: Geometric Logic
---

### Parametric Wavy 3D Truss Logic

1. **Profile Generation**:
   - Create a linear range of values (X-axis).
   - Apply a Sine function via `Evaluate` to generate Z-coordinates: `Z = sin(X * Frequency) * Amplitude`.
   - Use `Interpolate` to create the base wavy curve.

2. **3D Chord Positioning**:
   - **Bottom Chord 1**: The base wavy curve.
   - **Bottom Chord 2**: `Move` the base curve along the Y-axis by a `Width` factor.
   - **Top Chord**: `Move` the base curve by `Width / 2` (Y) and `Height` (Z) to create a triangular cross-section.

3. **Structural Webbing**:
   - `Divide Curve` all three chords by the same `Count`.
   - **Transverse Members**: `Line` between Bottom 1 and Bottom 2 points.
   - **Vertical/Slanted Webs**: `Line` between Bottom 1 -> Top and Bottom 2 -> Top.
   - **Diagonal Bracing**: Use `Shift List` (Wrap=False) on the Top Chord points to connect Bottom $i$ to Top $i+1$, creating the truss triangulation.

4. **Volumetric Realization**:
   - `Merge` all curve streams.
   - Apply `Pipe` with a `Radius` slider.
   - **Crucial**: Flatten (`m=f`) the input to `Pipe` to ensure all members are processed in a single operation.
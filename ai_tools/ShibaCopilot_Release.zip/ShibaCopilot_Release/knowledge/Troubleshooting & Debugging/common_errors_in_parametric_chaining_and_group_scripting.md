---
title: Common Errors in Parametric Chaining and Group Scripting
category: Troubleshooting & Debugging
---

### Error 1: Data Conversion Failed (Number to Vector)
**Cause**: Attempting to plug a `Number` (angle) into a `Vector` port (like the Axis port of a `Rotate` component) or vice versa.
**Fix**: Always verify the port type in the Master Dictionary. For `Rotate 3D`, the inputs are: 0:Geometry, 1:Angle (Number), 2:Center (Point), 3:Axis (Vector).

### Error 2: GH_GeometryGroup Attribute Errors in Scripting
**Cause**: In C# or Python scripts, `GH_GeometryGroup` (the wrapper for Grasshopper Groups) does not have a `.Value` property like `GH_Curve` or `GH_Number`.
**Fix**: To access geometry inside a group via script, you must cast it or use specific methods to explode the group. For simple verification, checking the `BoundingBox` of the `GH_GeometryGroup` object itself is often sufficient.

### Error 3: Off-by-One Connectivity
**Cause**: Using the `Partial Results` of `Mass Addition` directly as translation vectors.
**Fix**: The first segment should usually stay at the origin (translation `0,0,0`). The `Partial Results` represent the *end* points of segments. To get the *start* points, you must shift the list or prepend a zero vector and remove the last item.
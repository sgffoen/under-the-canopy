---
title: Shiba Assembly State and Sandbox Lessons
category: Lesson
---

### Shiba Assembly: State Command & GUID Persistence

#### 1. State Command (`S`) Requirements
- **The Error**: Attempting to use nicknames or IDs from previous turns in an `S` command (e.g., `S poly | h=true`) results in a `NodeCreationError: Component 'Unknown' not found`.
- **The Fix**: When modifying the state of a component created in a *previous* execution turn, you **MUST** use its absolute `Unique ID` (GUID) retrieved via `investigate_canvas`. 
- **Example**: 
    - Turn 1: `N poly | Polygon | Curve` -> Returns GUID `db0d6424...`
    - Turn 2: `S db0d6424... | h=true` (Correct)

#### 2. Python Sandbox Context
- **The Error**: `NameError: name 'ghenv' is not defined`.
- **The Fix**: The `test_in_sandbox` tool runs in a standard IronPython environment. It does not automatically include the `ghenv` or `scriptcontext` variables found in the Grasshopper Script component. To access the active Grasshopper document, use:
    ```python
    import Rhino
    import Grasshopper as gh
    doc = gh.Instances.ActiveCanvas.Document
    ```
- **Note**: Always verify geometry using `investigate_output_geometry` first, as it is more robust than custom scripts for simple metadata.
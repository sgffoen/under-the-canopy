---
title: Timber_House_Error_Log
category: Troubleshooting_Log
---

### Error: Rectangle Component Type Mismatch
**Issue**: Attempting to wire a `Number` slider directly into the `Plane (P)` input of the `Rectangle` component.
**Symptom**: Runtime Error: "Data conversion failed from Number to Plane".
**Solution**: Corrected the port indices. In the `Rectangle` component, `P` (Plane) is index 0, `X` (Size) is index 1, and `Y` (Size) is index 2. The sliders for width and depth must be wired to indices 1 and 2, respectively.

### Error: Twisted/Crossed Joists and Rafters
**Issue**: Inconsistent curve directions when dividing parallel boundary curves for bridging members (joists/rafters).
**Symptom**: Lines connecting points across curves appear crossed or "X" shaped.
**Solution**: Implemented the `Flip Curve` component using one curve as a `Guide` for the other. This ensures that both curves start and end at the same relative side of the building, resulting in parallel, aligned structural members.
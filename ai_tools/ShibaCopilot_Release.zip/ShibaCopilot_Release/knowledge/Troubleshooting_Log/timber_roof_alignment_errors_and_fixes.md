---
title: Timber_Roof_Alignment_Errors_and_Fixes
category: Troubleshooting_Log
---

### Issue: Twisted or Misaligned Roof Rafters
**Symptoms**: Rafters spanning the wrong direction (gable-to-gable instead of ridge-to-eave) or crossing/twisting.

**Root Causes**:
1. **Incorrect Segment Selection**: Selecting the short segments (gable ends) of a footprint instead of the long segments (eaves) for longitudinal rafters.
2. **Curve Direction Inconsistency**: Grasshopper's `Rectangle` or `Explode` components often produce segments with inconsistent start/end directions. Dividing these curves results in point lists that run in opposite directions.
3. **Data Tree Mismatch**: Connecting a ridge with 26 points to an eave with 17 points (due to different segment lengths) causes "bleeding" where the last point of the shorter list connects to all remaining points of the longer list.

**Solutions**:
1. **Surgical List Item**: Use `List Item` to explicitly pick parallel segments (e.g., Index 1 and 3 for eaves).
2. **Flip Curve Alignment**: Always use `Flip Curve` with a 'Guide' curve (usually the Ridge) to ensure all eave segments run in the same direction.
3. **Uniform Spacing**: Use `Divide Length` with the same spacing slider for all members to ensure point counts remain synchronized across parallel curves.
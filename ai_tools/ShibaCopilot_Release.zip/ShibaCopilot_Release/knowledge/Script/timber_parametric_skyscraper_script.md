---
title: Timber Parametric Skyscraper Script
category: Script
---

# PROMPT: Create a timber parametric skyscraper with floor plates, vertical columns, and a glass skin.
N sld_w | Number Slider | Params
C sld_w | val=20.0, min=10.0, max=50.0, d=1
N sld_d | Number Slider | Params
C sld_d | val=20.0, min=10.0, max=50.0, d=1
N sld_floors | Number Slider | Params
C sld_floors | val=30, min=5, max=100, d=0
N sld_h | Number Slider | Params
C sld_h | val=4.0, min=3.0, max=6.0, d=1
N sld_twist | Number Slider | Params
C sld_twist | val=60.0, min=0.0, max=180.0, d=1

N pt_base | Construct Point | Vector
S pt_base | h=true

N rect_base | Rectangle | Curve
S rect_base | h=true
W sld_w.0 > rect_base.1
W sld_d.0 > rect_base.2
W pt_base.0 > rect_base.0

N ser_h | Series | Sets
W sld_floors.0 > ser_h.2
W sld_h.0 > ser_h.1

N uz | Unit Z | Vector
S uz | h=true
W ser_h.0 > uz.0

N mov_floors | Move | Euclidean
S mov_floors | h=true
W rect_base.0 > mov_floors.0
W uz.0 > mov_floors.1

N dom_rot | Construct Domain | Math
P dom_rot.i0 | val=0
W sld_twist.0 > dom_rot.1

N sub_steps | Subtraction | Math
W sld_floors.0 > sub_steps.0
P sub_steps.i1 | val=1

N rng_rot | Range | Sets
W dom_rot.0 > rng_rot.0
W sub_steps.0 > rng_rot.1

N rad | Radians | Math
W rng_rot.0 > rad.0

N area_floors | Area | Surface
S area_floors | h=true
W mov_floors.0 > area_floors.0

N rot_floors | Rotate | Transform
S rot_floors | h=true
W mov_floors.0 > rot_floors.0
W rad.0 > rot_floors.1
W area_floors.1 > rot_floors.2

N srf_floors | Boundary Surfaces | Surface
W rot_floors.0 > srf_floors.0

N grp_floors | Group | Special
C grp_floors | n=1. Floor Generation, c=#DBABFF, ids=sld_w;sld_d;sld_floors;sld_h;sld_twist;pt_base;rect_base;ser_h;uz;mov_floors;dom_rot;sub_steps;rng_rot;rad;area_floors;rot_floors;srf_floors

N explode_crv | Explode | Curve
S explode_crv | h=true
W rot_floors.0 > explode_crv.0

N flip_pts | Flip Matrix | Sets
W explode_crv.1 > flip_pts.0

N poly_cols | Polyline | Curve
S poly_cols | h=true
W flip_pts.0 > poly_cols.0

N pipe_cols | Pipe | Surface
W poly_cols.0 > pipe_cols.0
P pipe_cols.i1 | val=0.5

N loft_skin | Loft | Surface
W rot_floors.0 > loft_skin.0

N grp_struct | Group | Special
C grp_struct | n=2. Structure & Skin, c=#ABDBFF, ids=explode_crv;flip_pts;poly_cols;pipe_cols;loft_skin

N col_timber | Colour Swatch | Params
C col_timber | val=#8B4513, a=255

N col_glass | Colour Swatch | Params
C col_glass | val=#ADD8E6, a=100

N prev_slabs | Custom Preview | Display
W srf_floors.0 > prev_slabs.0
W col_timber.0 > prev_slabs.1

N prev_cols | Custom Preview | Display
W pipe_cols.0 > prev_cols.0
W col_timber.0 > prev_cols.1

N prev_skin | Custom Preview | Display
W loft_skin.0 > prev_skin.0
W col_glass.0 > prev_skin.1

N scr_title | Scribble | Special
C scr_title | text=Timber Parametric Skyscraper, size=40

N grp_viz | Group | Special
C grp_viz | n=3. Visualization, c=#B2FAB4, ids=col_timber;col_glass;prev_slabs;prev_cols;prev_skin;scr_title
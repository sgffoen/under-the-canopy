---
title: Parametric Stadium Roof with Transverse Pleats
category: Architecture
---

### Parametric Stadium Roof with Transverse Pleats

**Concept:**
To create a sweeping, pleated stadium roof (similar to the Al Janoub Stadium), we can use a mathematical approach based on a parameter `t` sweeping from $0$ to $2\pi$. This avoids manual modeling of complex shells and allows for fully parametric control over the stadium's footprint, arching profile, and pleat frequency.

**Geometry Creation Logic:**
1.  **Parameterization:** Generate a sequence of values `t` from $0$ to $2\pi$ using a `Range` component.
2.  **Base Footprints (X/Y):** Define three elliptical paths using $\cos(t)$ and $\sin(t)$ multiplied by specific radii:
    *   **Outer Edge:** The footprint on the ground (e.g., $X = 120\cos(t)$, $Y = 80\sin(t)$).
    *   **Ridge Line:** The highest point of the roof.
    *   **Inner Edge:** The central pitch opening.
3.  **Arching Profile (Z):** The stadium dips down at the ends and arches up in the middle. This is achieved by multiplying the Z-heights by $\sin(t)^2$, which smoothly transitions from $0$ at the ends to $1$ at the sides.
4.  **Transverse Pleats (Z):** To get the ribbed texture, add a high-frequency sine wave (e.g., $\sin(t \times 40) \times 2$) to the Ridge Line's Z-height.
5.  **Rib Generation:** Graft the points from the Outer Edge, Ridge Line, and Inner Edge, and merge them. This creates branches where each branch contains the three points for a single transverse section. Use `Interpolate` to draw a curve through these three points, creating the structural ribs.
6.  **Lofting:** Flatten the list of rib curves and loft them together. The zigzagging ridge forces the lofted surface to fold into radiating pleats.

**Errors Solved:**
*   **Loft Failure (Data Trees):** Initially, the `Loft` component failed because the input curves were in separate branches (`t={0;x}(1)`). The fix was to flatten the input to the `Loft` component (`P loft.i0 | m=f`) so all curves are in a single list.
*   **Loft Seam Degeneracy:** When sweeping from $0$ to $2\pi$, the first and last curves are identical (overlapping). Lofting a closed sequence of curves where the start and end overlap can cause a degenerate seam or failure. The fix was to use `Cull Index` with index `-1` to remove the last overlapping curve before lofting.

**Shiba Assembly (Shorthand):**
```shiba
# PROMPT: Create a parametric stadium roof with an arching profile and transverse pleats.

# 1. PARAMETERIZATION (0 to 2*Pi)
N rng | Range | Sequence
P rng.i1 | val=80
N pi | Pi | Constants
N mul_pi | Multiplication | Operators
P mul_pi.i1 | val=2
W pi.0 > mul_pi.0
N mul_t | Multiplication | Operators
W rng.0 > mul_t.0
W mul_pi.0 > mul_t.1

# 2. MATH EVALUATION
N pan_cos | Panel | Special
C pan_cos | text=cos(x)
N eval_cos | Evaluate | Script
W pan_cos.0 > eval_cos.0
W mul_t.0 > eval_cos.1

N pan_sin | Panel | Special
C pan_sin | text=sin(x)
N eval_sin | Evaluate | Script
W pan_sin.0 > eval_sin.0
W mul_t.0 > eval_sin.1

N pan_sin2 | Panel | Special
C pan_sin2 | text=sin(x)*sin(x)
N eval_sin2 | Evaluate | Script
W pan_sin2.0 > eval_sin2.0
W mul_t.0 > eval_sin2.1

N pan_pleat | Panel | Special
C pan_pleat | text=sin(x*40)*2
N eval_pleat | Evaluate | Script
W pan_pleat.0 > eval_pleat.0
W mul_t.0 > eval_pleat.1

# 3. OUTER EDGE POINTS (Flat on ground)
N mul_ox | Multiplication | Operators
W eval_cos.0 > mul_ox.0
P mul_ox.i1 | val=120
N mul_oy | Multiplication | Operators
W eval_sin.0 > mul_oy.0
P mul_oy.i1 | val=80
N pt_out | Construct Point | Point
W mul_ox.0 > pt_out.0
W mul_oy.0 > pt_out.1
P pt_out.i2 | val=0

# 4. RIDGE LINE POINTS (Arched + Pleated)
N mul_rx | Multiplication | Operators
W eval_cos.0 > mul_rx.0
P mul_rx.i1 | val=90
N mul_ry | Multiplication | Operators
W eval_sin.0 > mul_ry.0
P mul_ry.i1 | val=60
N mul_rz | Multiplication | Operators
W eval_sin2.0 > mul_rz.0
P mul_rz.i1 | val=40
N add_rz | Addition | Operators
W mul_rz.0 > add_rz.0
W eval_pleat.0 > add_rz.1
N pt_ridge | Construct Point | Point
W mul_rx.0 > pt_ridge.0
W mul_ry.0 > pt_ridge.1
W add_rz.0 > pt_ridge.2

# 5. INNER EDGE POINTS (Arched opening)
N mul_ix | Multiplication | Operators
W eval_cos.0 > mul_ix.0
P mul_ix.i1 | val=60
N mul_iy | Multiplication | Operators
W eval_sin.0 > mul_iy.0
P mul_iy.i1 | val=40
N mul_iz | Multiplication | Operators
W eval_sin2.0 > mul_iz.0
P mul_iz.i1 | val=25
N add_iz | Addition | Operators
W mul_iz.0 > add_iz.0
P add_iz.i1 | val=5
N pt_in | Construct Point | Point
W mul_ix.0 > pt_in.0
W mul_iy.0 > pt_in.1
W add_iz.0 > pt_in.2

# 6. TRANSVERSE RIBS & LOFTING
N merge_pts | Merge | Sets
Z merge_pts | i=3, o=1
P merge_pts.i0 | m=g
P merge_pts.i1 | m=g
P merge_pts.i2 | m=g
W pt_out.0 > merge_pts.0
W pt_ridge.0 > merge_pts.1
W pt_in.0 > merge_pts.2

N rib_crv | Interpolate | Spline
W merge_pts.0 > rib_crv.0

# Cull the last overlapping rib to prevent a degenerate loft seam
N cull | Cull Index | Sequence
P cull.i0 | m=f
P cull.i1 | val=-1
W rib_crv.0 > cull.0

N loft | Loft | Freeform
W cull.0 > loft.0

# 7. ORGANIZATION
N grp_math | Group | Special
C grp_math | n=Math & Parameters, c=#ABDBFF, ids=rng;pi;mul_pi;mul_t;pan_cos;eval_cos;pan_sin;eval_sin;pan_sin2;eval_sin2;pan_pleat;eval_pleat

N grp_pts | Group | Special
C grp_pts | n=Profile Points, c=#DBABFF, ids=mul_ox;mul_oy;pt_out;mul_rx;mul_ry;mul_rz;add_rz;pt_ridge;mul_ix;mul_iy;mul_iz;add_iz;pt_in

N grp_geom | Group | Special
C grp_geom | n=Ribs & Shell Loft, c=#FFABAB, ids=merge_pts;rib_crv;cull;loft
```
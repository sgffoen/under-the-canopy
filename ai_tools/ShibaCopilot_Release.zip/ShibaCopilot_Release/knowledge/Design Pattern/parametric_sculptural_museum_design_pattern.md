---
title: Parametric Sculptural Museum Design Pattern
category: Design Pattern
---

### Parametric Sculptural Tower Pattern

This pattern creates a twisting, bulging architectural form suitable for museums or skyscrapers.

#### 1. Vertical Array
- **Series**: Generate Z-coordinates.
- **Unit Z**: Convert to vectors.
- **Rectangle**: Create base profile (use `Construct Domain` and `Negative` for centered rectangles).
- **Move**: Create the vertical stack.

#### 2. Centroid-Based Transformation
- **Area**: Extract the `Centroid` of each moved curve. This is critical so that `Rotate` and `Scale` happen around the local axis of each floor rather than the world origin.

#### 3. Non-Linear Scaling (The "Bulge")
- **Range**: Create a 0 to 1 domain with `N-1` steps.
- **Graph Mapper**: Use a Bezier or Sine curve to create a non-linear distribution.
- **Remap Numbers**: Map the 0-1 graph values to a physical scale range (e.g., 0.75 to 1.25).
- **Scale**: Apply to the curves using the centroids.

#### 4. Incremental Rotation (The "Twist")
- **Radians**: Convert a `Range` of degrees to radians.
- **Rotate**: Apply to the curves using the centroids.

#### 5. Envelope Generation
- **Loft**: Connect the transformed curves. Use `Flatten` on the input.
- **Boundary Surfaces**: Create solid floor plates from the same curves.
- **Custom Preview**: Use `Colour Swatch` with Alpha transparency for glass.
---
title: Parametric Twisting Skyscraper with Vertical Structure
category: Design Pattern
---

### Parametric Twisting Skyscraper Logic

This pattern describes the creation of a twisting tower with integrated vertical structure and skin.

#### 1. Floor Plate Generation
- **Base**: Create a `Rectangle` at a base point.
- **Vertical Array**: Use `Series` to generate Z-offsets based on floor count and floor height.
- **Movement**: Use `Move` with `Unit Z` to create the stack of floor curves.

#### 2. Parametric Twist
- **Domain**: Create a rotation domain from 0 to the `Twist Angle`.
- **Incremental Angles**: Use `Range` to divide the domain by the number of floors (minus 1).
- **Rotation**: Convert degrees to `Radians` and use the `Rotate` (Transform) component. Use the `Centroid` from an `Area` component as the rotation center for each floor to ensure the tower twists around its own axis.

#### 3. Vertical Structural Extraction (Timber Columns)
- **Explode**: Deconstruct the rotated floor rectangles into vertices.
- **Data Tree Manipulation**: The vertices are structured as `Branch = Floor, Item = Corner`. Use `Flip Matrix` to transpose the tree to `Branch = Corner, Item = Floor`.
- **Columns**: Connect the transposed points using `Polyline`. This creates vertical lines following the twist.
- **Thickening**: Use `Pipe` to give the columns physical dimension.

#### 4. Building Envelope
- **Skin**: Use `Loft` on the list of rotated floor curves to generate a continuous surface representing the glass facade.

#### 5. Visualization
- Use `Custom Preview` with `Colour Swatch` to distinguish between timber elements (Slabs/Columns) and glass (Skin).
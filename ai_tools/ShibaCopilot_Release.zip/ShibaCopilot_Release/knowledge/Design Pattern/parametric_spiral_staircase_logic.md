---
title: Parametric Spiral Staircase Logic
category: Design Pattern
---

### Parametric Spiral Staircase Logic

This pattern creates a spiral staircase with a central structural pole and wedge-like steps.

#### 1. Vertical Distribution (The Rise)
- **Total Height & Count**: Use `Number Sliders` for total height and number of steps.
- **Step Interval**: Divide total height by step count to get the rise per step.
- **Z-Stack**: Use `Series` to generate a list of Z-coordinates starting from 0.
- **Points**: Use `Construct Point` and `Move` (with `Unit Z`) to create the vertical array of step origins.

#### 2. Rotational Distribution (The Spiral)
- **Total Rotation**: Use a `Number Slider` for total degrees (e.g., 360).
- **Angle Range**: Use `Construct Domain` (0 to TotalRotation) and `Range` (steps = count - 1) to create incremental rotation values.
- **Conversion**: Convert degrees to `Radians`.

#### 3. Step Geometry (The Tread)
- **Profile**: Use `Rectangle` or `Polygon` at each moved point. The width represents the tread width, and the length represents the staircase radius.
- **Rotation**: Use `Rotate` to spin each profile around its respective origin point using the calculated radians.
- **Surface**: Use `Boundary Surfaces` to turn the profiles into planar treads.
- **Thickness**: Use `Extrude` with `Unit Z` to give the steps physical depth.

#### 4. Central Support (The Pole)
- **Base**: Use `Circle` at the global origin (0,0,0).
- **Height**: `Extrude` the circle using the total height value to create a continuous central pole.

#### 5. Visualization
- Use `Custom Preview` with `Colour Swatch` to distinguish between the steps and the pole.
- Hide (`h=true`) all intermediate construction geometry (points, rectangles, base surfaces).
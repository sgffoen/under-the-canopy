---
title: Parametric Twisting Tower Logic
category: Design Pattern
---

### Parametric Twisting Tower Logic

This pattern creates a skyscraper with a twisting profile and internal floor plates.

#### 1. Vertical Array
- **Base Profile**: Use `Polygon` (or `Rectangle`) to define the footprint.
- **Z-Stack**: Use `Series` to create a list of heights. Connect this to `Unit Z` and then to the `T` (Motion) input of a `Move` component.
- **Input**: `Geometry` -> Base Profile; `Motion` -> Z-Vectors.

#### 2. Rotational Twist
- **Angle Range**: Use `Construct Domain` (0 to TwistAngle) and `Range` to create incremental rotation values for each floor.
- **Centroid Alignment**: Use `Area` on the moved curves to get their `Centroid`. This is critical; rotating around the global origin (0,0,0) will cause the tower to lean/spiral away from the center, while rotating around the centroid keeps it on-axis.
- **Transformation**: Use `Rotate`. 
    - `G` (Geometry): Moved curves.
    - `A` (Angle): Range values (converted via `Radians`).
    - `P` (Plane/Point): Centroids.

#### 3. Form Generation
- **Skin**: Use `Loft` on the rotated curves. This creates a single Brep representing the facade.
- **Slabs**: Use `Boundary Surfaces` on the rotated curves to create planar floor plates.

#### 4. Visualization
- Use `Custom Preview` with `Colour Swatch`. 
- Set the Skin to a transparent material (Alpha < 255) to see the internal slabs.
- Hide (`h=true`) all intermediate construction geometry (polygons, points, moved curves) to keep the Rhino viewport clean.
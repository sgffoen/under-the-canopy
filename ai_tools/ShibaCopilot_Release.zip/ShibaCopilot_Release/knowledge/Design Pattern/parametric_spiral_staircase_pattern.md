---
title: Parametric Spiral Staircase Pattern
category: Design Pattern
---

### Parametric Spiral Staircase Logic

This pattern creates a parametric spiral staircase with a central structural pole and rectangular treads.

#### 1. Vertical Distribution (The Rise)
- **Total Height & Count**: Use `Number Sliders` for total height (`H`) and number of steps (`N`).
- **Step Interval**: Divide `H` by `N` to get the rise per step.
- **Z-Stack**: Use `Series` to generate a list of Z-coordinates starting from 0.
- **Points**: Use `Construct Point` and `Move` (with `Unit Z`) to create the vertical array of step origins.

#### 2. Rotational Distribution (The Spiral)
- **Total Rotation**: Use a `Number Slider` for total degrees (e.g., 360).
- **Angle Range**: Use `Construct Domain` (0 to TotalRotation) and `Range` (steps = N - 1) to create incremental rotation values.
- **Conversion**: Convert degrees to `Radians`.

#### 3. Step Geometry (The Tread)
- **Profile**: Use `Rectangle` at each moved point. 
    - **X-Domain**: `Construct Domain` (0 to Radius) defines the length of the tread.
    - **Y-Domain**: `Construct Domain` (-Width/2 to +Width/2) centers the tread on the rotation axis.
- **Rotation**: Use `Rotate` to spin each rectangle around its respective origin point using the calculated radians.
- **Surface**: Use `Boundary Surfaces` to turn the profiles into planar treads.
- **Thickness**: Use `Extrude` with `Unit Z` to give the steps physical depth.

#### 4. Central Support (The Pole)
- **Base**: Use `Circle` at the global origin (0,0,0).
- **Height**: `Extrude` the circle using the total height value to create a continuous central pole.

#### 5. Visualization
- Organize components into logical groups: `Inputs`, `Math`, `Steps`, and `Pole`.
- Hide (`h=true`) all intermediate construction geometry (points, rectangles, base surfaces) to keep the viewport clean.
---
title: Parametric Twisted Tower Logic
category: Design Pattern
---

### Twisted Tower Parametric Logic

This pattern creates a skyscraper with a twisting profile, internal floor plates, and a lofted skin.

#### 1. Vertical Stack (The Skeleton)
- **Base Curve**: Use `Polygon` or `Rectangle`.
- **Z-Distribution**: Use `Series` to define floor heights.
- **Translation**: Use `Move` with `Unit Z` to create the vertical array of profiles.

#### 2. On-Axis Rotation (The Twist)
- **Centroid Alignment**: Use `Area` on the moved curves to get their `Centroid`. Rotating around the centroid ensures the tower twists in place rather than spiraling outward.
- **Angle Distribution**: 
    - Create a domain (0 to TotalTwist) using `Construct Domain`.
    - Use `Range` to create incremental steps. The number of steps should be `Floors - 1`.
    - Convert degrees to `Radians`.
- **Transformation**: Use `Rotate`. Connect the moved curves to `G`, the radians to `A`, and the centroids to `P`.

#### 3. Surface Generation (The Body)
- **Facade**: Use `Loft` on the rotated curves.
- **Floor Slabs**: Use `Boundary Surfaces` on the rotated curves.

#### 4. Visualization
- Use `Custom Preview` with `Colour Swatch`.
- Set the skin to a lower Alpha (transparency) to reveal the internal slabs.
- Hide intermediate construction geometry (`S ID | h=true`).
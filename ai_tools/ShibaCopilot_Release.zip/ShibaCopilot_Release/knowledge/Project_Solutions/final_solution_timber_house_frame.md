---
title: Final_Solution_Timber_House_Frame
category: Project_Solutions
---

# Complete Parametric Timber House Frame

This solution provides a robust, error-free timber framing script including floor joists, wall studs, and a gabled roof.

### Shorthand Implementation:
```shiba
# Inputs
N sld_w | Number Slider | Params | C sld_w | val=10.0, min=5.0, max=20.0
N sld_d | Number Slider | Params | C sld_d | val=15.0, min=5.0, max=30.0
N sld_spc | Number Slider | Params | C sld_spc | val=0.6, min=0.4, max=1.2
N sld_h | Number Slider | Params | C sld_h | val=3.0, min=2.4, max=5.0

# Footprint
N rect | Rectangle | Curve
N expl | Explode | Curve | W rect.0 > expl.0

# Floor Joists (Aligned)
N seg0 | List Item | List | W expl.0 > seg0.0 | P seg0.i1 | val=0
N seg2 | List Item | List | W expl.0 > seg2.0 | P seg2.i1 | val=2
N flip_f | Flip Curve | Curve | W seg2.0 > flip_f.0 | W seg0.0 > flip_f.1
N div_f1 | Divide Length | Curve | W seg0.0 > div_f1.0 | W sld_spc.0 > div_f1.1
N div_f2 | Divide Length | Curve | W flip_f.0 > div_f2.0 | W sld_spc.0 > div_f2.1
N joists | Line | Curve | W div_f1.0 > joists.0 | W div_f2.0 > joists.1

# Wall Studs
N div_w | Divide Length | Curve | W expl.0 > div_w.0 | W sld_spc.0 > div_w.1
N studs | Line SDL | Curve | W div_w.0 > studs.0 | P studs.i1 | val={0,0,1} | W sld_h.0 > studs.2

# Roof Rafters (Aligned to Ridge)
N mid0 | Point on Curve | Params | W seg0.0 > mid0.0 | P mid0.i0 | val=0.5
N mid2 | Point on Curve | Params | W seg2.0 > mid2.0 | P mid2.i0 | val=0.5
N ridge_ln | Line | Curve | W mid0.0 > ridge_ln.0 | W mid2.0 > ridge_ln.1
N ridge_mv | Move | Transform | W ridge_ln.0 > ridge_mv.0 | P ridge_mv.i1 | val={0,0,5.5}
N seg1 | List Item | List | W expl.0 > seg1.0 | P seg1.i1 | val=1
N flip_e | Flip Curve | Curve | W seg1.0 > flip_e.0 | W ridge_mv.0 > flip_e.1
N eave_mv | Move | Transform | W flip_e.0 > eave_mv.0 | P eave_mv.i1 | val={0,0,3}
N div_r | Divide Length | Curve | W ridge_mv.0 > div_r.0 | W sld_spc.0 > div_r.1
N div_e | Divide Length | Curve | W eave_mv.0 > div_e.0 | W sld_spc.0 > div_e.1
N rafters | Line | Curve | W div_r.0 > rafters.0 | W div_e.0 > rafters.1
```

### Key Features:
- **Directional Safety**: Uses `Flip Curve` to ensure all parallel members are synchronized.
- **Parametric Spacing**: A single slider controls the density of the entire structure.
- **Clean Data Trees**: All division counts match, preventing geometric "bleeding" at the ends of lists.
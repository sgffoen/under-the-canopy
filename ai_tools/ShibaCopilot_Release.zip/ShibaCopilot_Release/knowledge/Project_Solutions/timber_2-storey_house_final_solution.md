---
title: Timber_2-Storey_House_Final_Solution
category: Project_Solutions
---

# 2-Storey Timber House Structure (Native Grasshopper)

This solution provides a complete, parametric timber frame including studs, joists, and rafters.

### Shorthand Implementation Snippet:
```shiba
# Base Footprint
N rect_base | Rectangle | Curve
W sld_w.0 > rect_base.1
W sld_d.0 > rect_base.2

# Ground Studs
N expl_base | Explode | Curve
W rect_base.0 > expl_base.0
N div_len | Divide Length | Curve
W expl_base.0 > div_len.0
W sld_s.0 > div_len.1
N stud_g | Line SDL | Curve
W div_len.0 > stud_g.0
W unit_z.0 > stud_g.2

# Floor Joists (Aligned)
N flip_seg | Flip Curve | Curve
W list_seg2.0 > flip_seg.0
W list_seg0.0 > flip_seg.1
N joists | Line | Curve
W div_j1.0 > joists.0
W div_j2.0 > joists.1
```

### Key Features:
- **Directional Alignment**: Uses `Flip Curve` to prevent twisted geometry.
- **Modular Spacing**: All members (studs, joists, rafters) respond to a single spacing slider.
- **Multi-Storey**: Logic is stacked using `Move` (Unit Z) for the second floor and roof plates.
- **Clean Layout**: Fully grouped and color-coded for architectural clarity.
---
title: Tensile Membrane Form-Finding Logic
category: Design Patterns
---

### Tensile Membrane with Structural Ribs

#### 1. Boundary Condition Logic (The Ribs)
- **Parametric Arches**: Created a series of `Arc` components on the `YZ Plane`.
- **Undulation**: Used a `Panel` with a list of radii (`5, 8, 12, 8, 5`) to create a varying height profile along the X-axis.
- **Discretization**: Used `Divide Curve` on the arches to generate the specific points that would act as `Anchor` goals for the physics simulation.

#### 2. Form-Finding Logic (The Membrane)
- **Initial State**: Generated a `Loft` between the arches and converted it to a `Mesh Brep`. This provides the starting topology.
- **Tension Simulation**:
    - **EdgeLengths**: Applied a `LengthFactor` of `0.1`. This forces the mesh edges to try and shrink to 10% of their original length, creating the "soap film" effect.
    - **Anchors**: Fixed the mesh vertices corresponding to the arch division points.
- **Equilibrium**: The `BouncySolver` balances the shrinking force of the edges against the fixed positions of the anchors, resulting in a minimal surface (anticlastic curvature).

#### 3. Visualization & Detailing
- **Primary Structure**: `Pipe` the original arch curves to represent rigid steel/timber ribs.
- **Secondary Grid**: `Pipe` the `Interior Edges` of the relaxed mesh to represent a cable net or fabric reinforcement grid.
- **Membrane**: `Custom Preview` with a `Colour Swatch` (Gold/Yellow) on the relaxed mesh.

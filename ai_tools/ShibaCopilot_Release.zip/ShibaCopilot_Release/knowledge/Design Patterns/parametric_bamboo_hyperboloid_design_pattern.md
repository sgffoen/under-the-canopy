---
title: Parametric Bamboo Hyperboloid Design Pattern
category: Design Patterns
---

# Parametric Bamboo Hyperboloid Lattice

### Concept
A one-sheeted hyperboloid is a doubly-ruled surface. In bamboo architecture, this is achieved by connecting two circular rings with straight poles that are offset (twisted) relative to each other.

### Geometry Logic
1. **Boundary Circles**: Create two circles (Base and Top) at a distance $H$.
2. **Discretization**: Use `Divide Curve` on both circles with $N$ segments to get two lists of points.
3. **Twist (The "Rule")**: 
   - Use `Shift List` on the Top points by a value $S$.
   - Connect Base points to Shifted Top points using `Line`.
   - For a symmetric lattice, create a second set of lines using a negative shift $-S$.
4. **Waist Calculation**: The structure narrows at the center. The waist radius $r$ is defined by $r = R \cdot \cos(\theta/2)$, where $\theta$ is the total twist angle ($2\pi \cdot S / N$).
5. **Hoops/Rings**: Use `Range` to generate heights and `Circle` components to create horizontal stabilizing rings.
6. **Physicality**: Use `Pipe` on all lines and circles to represent bamboo poles.

### Shorthand Snippet (Core)
```shiba
N div_base | Divide Curve | Curve
W circ_base.0 > div_base.0
W sld_n.0 > div_base.1

N shift_a | Shift List | Sets
W div_top.0 > shift_a.0
W sld_shift.0 > shift_a.1

N line_a | Line | Curve
W div_base.0 > line_a.0
W shift_a.0 > line_a.1
```

### Key Parameters
- **Radius ($R$)**: Base and top radius.
- **Height ($H$)**: Vertical distance.
- **Divisions ($N$)**: Number of bamboo poles per direction.
- **Shift ($S$)**: Determines the "waist" and the slope of the poles.

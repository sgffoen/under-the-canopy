---
title: Parametric Steel Warehouse Design Pattern
category: Design Patterns
---

### Steel Warehouse Portal Frame Logic

#### 1. Primary Frame (X-Z Plane)
- **Points**: Construct 5 points: Base Left `{0,0,0}`, Base Right `{W,0,0}`, Eave Left `{0,0,He}`, Eave Right `{W,0,He}`, and Ridge `{W/2,0,Hr}`.
- **Lines**: Connect Base to Eave (Columns) and Eave to Ridge (Rafters).

#### 2. Longitudinal Array (Y-Axis)
- **Spacing**: `Total Length / Number of Bays`.
- **Series**: Generate a list of Y-coordinates starting at 0 with the calculated spacing.
- **Move**: Use `Unit Y` vectors to move the 4 frame lines and the 3 top points (Eave L, Eave R, Ridge).

#### 3. Secondary Structure & Envelope
- **Purlins**: Use `Polyline` on the moved point sets (Eave L, Eave R, Ridge) to create longitudinal members.
- **Cladding**: Use `Loft` between the longitudinal polylines. 
    - *Wall L*: Loft between Base L Polyline and Eave L Polyline.
    - *Roof L*: Loft between Eave L Polyline and Ridge Polyline.
    - *Repeat for Right side.*

#### 4. Visualization
- **Steel**: Dark Gray swatch for lines.
- **Cladding**: Semi-transparent Light Blue swatch for surfaces.
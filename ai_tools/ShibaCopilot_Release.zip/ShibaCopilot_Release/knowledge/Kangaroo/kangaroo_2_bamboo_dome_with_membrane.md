---
title: Kangaroo 2 Bamboo Dome with Membrane
category: Kangaroo
---

To create an inflated bamboo dome with a tensile membrane using Kangaroo 2:
1. Create a base `Mesh Plane`.
2. Use `NakedVertices` to separate the perimeter (NakedPts) from the interior (ClothedPts).
3. Apply `Anchor` goals to the NakedPts (strength 10000).
4. Apply `Load` goals (Z-vector) to the ClothedPts to inflate the mesh.
5. Apply `EdgeLengths` to the mesh to act as structural springs.
6. Pass the mesh through a `Show` goal.
7. `Entwine` all goals (Anchors, Loads, EdgeLengths, Show) and plug into the Kangaroo `Solver`.
8. CRITICAL EXTRACTION: The Solver's `O` (Output) port returns all goal geometries in a tree. To extract the relaxed mesh, flatten the `O` output and use `List Item` with index `-1` (assuming `Show` was the last branch in the Entwine).
9. Pass the extracted mesh into `Mesh Edges`, merge the Naked and Interior edges, and feed them into `MultiPipe` to generate a smooth SubD bamboo frame.
10. Apply `Custom Preview` to the MultiPipe (bamboo material) and the extracted mesh (membrane material).
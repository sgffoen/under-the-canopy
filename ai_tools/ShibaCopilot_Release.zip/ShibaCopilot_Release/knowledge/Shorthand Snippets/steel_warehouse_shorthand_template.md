---
title: Steel Warehouse Shorthand Template
category: Shorthand Snippets
---

# PROMPT: Standard Portal Frame Array
# Inputs: sld_w, sld_h_eave, sld_h_ridge, sld_len, sld_bays

# 1. Create Base Frame Lines (ln_col_l, ln_col_r, ln_raf_l, ln_raf_r)
# 2. Calculate Spacing (div_spacing)
# 3. Generate Y-Series (ser_y)
# 4. Move Lines:
N mov_col_l | Move | Transform
W ln_col_l.0 > mov_col_l.0
W vec_y.0 > mov_col_l.1

# 5. Create Purlins (pl_ridge):
N mov_pt_r | Move | Transform
W pt_ridge.0 > mov_pt_r.0
W vec_y.0 > mov_pt_r.1
N pl_ridge | Polyline | Curve
W mov_pt_r.0 > pl_ridge.0

# 6. Loft Cladding:
N loft_roof | Loft | Surface
N merge_roof | Merge | Sets
W pl_eave.0 > merge_roof.0
W pl_ridge.0 > merge_roof.1
W merge_roof.0 > loft_roof.0